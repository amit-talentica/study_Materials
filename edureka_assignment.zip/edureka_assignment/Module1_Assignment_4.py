"""
@author: Amit Kumar Manjhi
@Date: 03-02-2020
"""
print("1. Character formatting = %c, %c, %c" % (97, 64, 77))
print("2. Signed Decimal Integers = %i, %d" % (-97, +91))
print("3. Octal Integer = %o" % 0o77774)
print("4. Hexadecimal Integer(Uppercase) = %X" % 0X1024AE)
print("5. Floating Point Real Number = %f" % 123.7895)
print("6. Exponential(lowercase e) notation = %e" % 3.14e-4)

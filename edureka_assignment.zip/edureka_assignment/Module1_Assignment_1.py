"""
@author : Amit Kumar Manjhi
@date : 03/02/2020
"""
string = "Discover, Learning, with, Edureka"

print("Number of lower case 'a' = %d" % string.count("a"))
print("Number of lower case 'o' = %d" % string.count("o"))
print("Number of upper case 'L' = %d" % string.count("L"))
print("Number of upper case 'N' = %d" % string.count("N"))
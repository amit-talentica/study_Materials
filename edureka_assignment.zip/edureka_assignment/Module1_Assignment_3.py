"""
@author : Amit Kumar Manjhi
@date : 03/02/2020
"""

print("->Type of 0X7AE (Hex) =", type(0X7AE), "\n=>Value =", 0X7AE, "\n")
print("->Type of 3+4j (Complex) =", type(3+4j), "\n=>Value =", 3+4j, "\n")
print("->Type of -0o1234 (Octal) =", type(-0o1234), "\n=>Value =", -0o1234, "\n")
print("->Type of 3.14e-2 (Exponential) =", type(3.14e-2), "\n=>Value =", 3.14e-2, "\n")